# Ng Dung Portfolio Design System

## Aesthetic Stance
**Minimalist** — Clean, focused, maximum impact with minimal elements. One hero statement, generous whitespace, precise typography, and a split-canvas treatment that creates visual tension.

## Canvas Treatment
**Two-tone vertical split** — The portfolio uses a vertical divide to create distinct zones. The left side serves as a darker anchor, the right as a lighter workspace. This asymmetry draws attention and creates depth.

## Typography
- **Display**: Helvetica Neue / Arial (neo-grotesque sans) — Clean, precise, modern
- **Body**: System sans-serif stack for optimal readability
- Hierarchy: Large display type for name/titles, medium for sections, small for labels

## Color Palette
- **Primary background**: Deep charcoal (#0a0a0a) — left panel
- **Secondary background**: Off-white (#fafafa) — right panel  
- **Accent**: Electric blue (#0066ff) — interactive elements, CTAs
- **Text on dark**: Pure white (#ffffff)
- **Text on light**: Deep charcoal (#0a0a0a)
- **Borders**: Subtle, low-opacity (#ffffff20 on dark, #00000010 on light)

## Layout Principles
- Use CSS Grid for the main split-canvas structure
- Generous whitespace — let content breathe
- Asymmetric composition — avoid equal columns
- Left panel: navigation, branding, key info
- Right panel: main content, hero statement, CTAs

## Visual Details
- Minimal borders, hairline rules only
- Subtle hover states with color transitions
- Focus states with 2px outline in accent color
- Button CTAs with solid fills and clear affordances
- Skills displayed as clean tags/pills with subtle backgrounds

## Responsive Behavior
- Breakpoint at ~1000px: stack panels vertically
- Mobile: single column, maintain hierarchy
- Preserve whitespace ratios across viewports

## Content Guidelines
- Use real, meaningful content (no lorem ipsum)
- Skills: Technical precision (C++, Python, Java, AI, Prompt)
- Tone: Professional, confident, focused on AI/3D expertise
