import { motion } from "motion/react";

export function Navigation() {
  const navItems = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Evidence", href: "#evidence" },
    { label: "Reflection", href: "#reflection" },
    { label: "Contact", href: "#contact" }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-sidebar/95 backdrop-blur-sm border-b border-sidebar-border z-50 px-8 py-4">
      <div className="flex items-center justify-between">
        <motion.a
          href="#home"
          className="text-white tracking-tight text-lg"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          Ng Dung
        </motion.a>
        <div className="flex gap-6 text-sm">
          {navItems.map((item, index) => (
            <motion.a
              key={item.label}
              href={item.href}
              className="relative"
              style={{ color: "rgba(255, 255, 255, 0.7)" }}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
              whileHover={{ color: "rgba(255, 255, 255, 1)" }}
            >
              {item.label}
              <motion.div
                className="absolute -bottom-1 left-0 right-0 h-[2px] bg-[#0066ff]"
                initial={{ scaleX: 0 }}
                whileHover={{ scaleX: 1 }}
                transition={{ duration: 0.3 }}
              />
            </motion.a>
          ))}
        </div>
      </div>
    </nav>
  );
}
