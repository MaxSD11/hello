import { motion } from "motion/react";

interface ProjectCardProps {
  title: string;
  goal: string;
  process: string;
  finalProduct: string;
  evidence: string;
  lesson: string;
  index: number;
}

function ProjectCard({
  title,
  goal,
  process,
  finalProduct,
  evidence,
  lesson,
  index,
}: ProjectCardProps) {
  return (
    <motion.div
      className="bg-card border border-border rounded-xl p-8 hover:border-primary/50 transition-colors"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
    >
      <h3 className="text-xl mb-6 text-primary">{title}</h3>

      <div className="space-y-4 text-sm">
        <div>
          <h4 className="uppercase tracking-wider text-xs text-muted-foreground mb-2">Goal</h4>
          <p>{goal}</p>
        </div>

        <div>
          <h4 className="uppercase tracking-wider text-xs text-muted-foreground mb-2">Process</h4>
          <p>{process}</p>
        </div>

        <div>
          <h4 className="uppercase tracking-wider text-xs text-muted-foreground mb-2">
            Final Product
          </h4>
          <p>{finalProduct}</p>
        </div>

        <div>
          <h4 className="uppercase tracking-wider text-xs text-muted-foreground mb-2">Evidence</h4>
          <p>{evidence}</p>
        </div>

        <div>
          <h4 className="uppercase tracking-wider text-xs text-muted-foreground mb-2">
            Personal Lesson
          </h4>
          <p className="italic">{lesson}</p>
        </div>
      </div>
    </motion.div>
  );
}

export function Projects() {
  const projects = [
    {
      title: "File and Folder Management",
      goal: "Develop systematic file organization skills for academic and professional work.",
      process:
        "Created hierarchical folder structures, implemented consistent naming conventions, and established backup protocols for important documents.",
      finalProduct:
        "A well-organized digital workspace with categorized folders for courses, projects, and personal work.",
      evidence: "Screenshots of organized file system and documentation of naming conventions.",
      lesson:
        "Good organization saves time and reduces stress. A systematic approach to file management is essential for productivity.",
    },
    {
      title: "Academic Search and Information Evaluation",
      goal: "Master effective research techniques and critical evaluation of digital sources.",
      process:
        "Utilized Google Scholar, academic databases, and evaluated sources using CRAAP criteria (Currency, Relevance, Authority, Accuracy, Purpose).",
      finalProduct:
        "Annotated bibliography with credible sources and documented evaluation process.",
      evidence: "Research logs, source evaluation worksheets, and final bibliography.",
      lesson:
        "Not all information online is reliable. Critical thinking and proper evaluation are crucial for academic integrity.",
    },
    {
      title: "Effective Prompt Writing",
      goal: "Learn to craft precise prompts for AI tools to generate useful outputs.",
      process:
        "Experimented with various prompt structures, refined through iterative testing, and documented best practices for different AI applications.",
      finalProduct:
        "Prompt engineering guide with examples and a collection of effective prompts for different use cases.",
      evidence: "Prompt templates, comparison of outputs, and documented refinement process.",
      lesson:
        "Specificity and context are key to getting meaningful results from AI. Prompt engineering is a valuable skill in the AI era.",
    },
    {
      title: "Online Collaboration Tools",
      goal: "Develop proficiency in digital collaboration platforms for remote teamwork.",
      process:
        "Used tools like Google Workspace, Microsoft Teams, and project management platforms for group assignments and communication.",
      finalProduct:
        "Successfully completed group projects using collaborative documents, shared calendars, and task management systems.",
      evidence: "Collaboration logs, shared documents, and team feedback.",
      lesson:
        "Clear communication and proper use of collaboration tools are essential for successful remote teamwork.",
    },
    {
      title: "Generative AI for Digital Content Creation",
      goal: "Explore generative AI tools for creating text, images, and multimedia content.",
      process:
        "Experimented with ChatGPT, DALL-E, and other AI tools to generate content, then refined and customized outputs for specific purposes.",
      finalProduct:
        "Portfolio of AI-assisted content including written materials, visual assets, and this web portfolio.",
      evidence: "Before/after comparisons, prompt logs, and final creative outputs.",
      lesson:
        "AI is a powerful creative assistant, but human creativity and critical judgment are irreplaceable for quality results.",
    },
    {
      title: "Responsible AI in Learning and Research",
      goal: "Understand ethical considerations and best practices for AI use in academic contexts.",
      process:
        "Studied AI ethics, plagiarism concerns, bias in AI systems, and developed guidelines for responsible AI use in academic work.",
      finalProduct:
        "Personal AI ethics framework and documented practices for transparent AI use in assignments.",
      evidence: "Ethics reflection paper, citation practices, and AI disclosure statements.",
      lesson:
        "AI should augment learning, not replace it. Transparency and ethical use are fundamental to maintaining academic integrity.",
    },
  ];

  return (
    <section id="projects" className="px-8 lg:px-16 py-24 bg-background">
      <motion.h2
        className="text-4xl tracking-tight mb-4"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        Projects
      </motion.h2>
      <motion.p
        className="text-muted-foreground mb-12 max-w-2xl"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        Academic assignments demonstrating digital literacy and AI competency
      </motion.p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {projects.map((project, index) => (
          <ProjectCard key={project.title} {...project} index={index} />
        ))}
      </div>
    </section>
  );
}
