import { motion } from "motion/react";

export function Skills() {
  const skills = [
    "File Management",
    "Academic Search",
    "Prompt Engineering",
    "Online Collaboration",
    "Generative AI",
    "Responsible AI",
    "Web Portfolio Design"
  ];

  return (
    <section id="skills" className="px-8 lg:px-16 py-24 bg-background">
      <motion.h2
        className="text-4xl tracking-tight mb-4"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        Skills
      </motion.h2>
      <motion.p
        className="text-muted-foreground mb-12 max-w-2xl"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        Digital competencies developed through academic and professional practice
      </motion.p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {skills.map((skill, index) => (
          <motion.div
            key={skill}
            className="px-6 py-4 bg-card border border-border rounded-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.4,
              delay: index * 0.1,
              ease: [0.22, 1, 0.36, 1]
            }}
            whileHover={{ scale: 1.05, borderColor: "#0066ff" }}
          >
            {skill}
          </motion.div>
        ))}
      </div>
    </section>
  );
}
