import { motion } from "motion/react";

export function Hero() {
  return (
    <div className="flex flex-col items-center justify-center px-8 py-24 text-center max-w-5xl mx-auto">
      <motion.div
        className="text-6xl mb-8"
        initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
        animate={{ opacity: 1, scale: 1, rotate: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      >
        🎨
      </motion.div>

      <motion.h1
        className="text-[5rem] leading-[0.9] tracking-tight mb-6 text-white"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
      >
        I AM<br />NG DUNG
      </motion.h1>

      <motion.p
        className="text-xl mb-2"
        style={{ color: "rgba(255, 255, 255, 0.9)" }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
      >
        Software Developer
      </motion.p>

      <motion.p
        className="text-lg mb-12"
        style={{ color: "rgba(255, 255, 255, 0.7)" }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
      >
        AI & Digital Literacy Portfolio
      </motion.p>

      <motion.div
        className="flex gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
      >
        <motion.a
          href="#projects"
          className="bg-[#0066ff] text-white px-8 py-3 rounded-lg"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >
          View Projects
        </motion.a>
        <motion.a
          href="#contact"
          className="border-2 px-8 py-3 rounded-lg text-white"
          style={{ borderColor: "rgba(255, 255, 255, 0.3)" }}
          whileHover={{ scale: 1.05, borderColor: "rgba(255, 255, 255, 0.6)" }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >
          Contact Me
        </motion.a>
      </motion.div>

      <motion.div
        className="mt-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.2 }}
      >
        <motion.a
          href="#about"
          className="text-sm uppercase tracking-wider"
          style={{ color: "rgba(255, 255, 255, 0.5)" }}
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          Scroll to explore
          <div className="text-center mt-2">↓</div>
        </motion.a>
      </motion.div>
    </div>
  );
}
