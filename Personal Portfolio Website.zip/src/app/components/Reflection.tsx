import { motion } from "motion/react";

export function Reflection() {
  return (
    <section id="reflection" className="px-8 lg:px-16 py-24 bg-background">
      <div className="max-w-4xl mx-auto">
        <motion.h2
          className="text-4xl tracking-tight mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Reflection
        </motion.h2>

        <motion.div
          className="space-y-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div>
            <h3 className="text-xl mb-4 text-primary">What I Learned</h3>
            <p className="leading-relaxed">
              Throughout this academic journey, I have gained invaluable digital literacy skills
              that extend far beyond basic computer usage. I learned how to organize information
              systematically, evaluate sources critically, and leverage AI tools responsibly. The
              most significant realization was understanding that technology is not just about
              using tools, but about thinking critically about how and when to use them
              effectively.
            </p>
          </div>

          <div>
            <h3 className="text-xl mb-4 text-primary">Challenges I Faced</h3>
            <p className="leading-relaxed">
              One of the biggest challenges was learning to write effective prompts for AI tools.
              Initially, my prompts were too vague, resulting in generic outputs. I also struggled
              with organizing large amounts of digital information and determining which sources
              were credible for academic research. The ethical considerations of using AI in
              academic work presented another challenge, as I had to find the balance between
              leveraging AI assistance and maintaining academic integrity.
            </p>
          </div>

          <div>
            <h3 className="text-xl mb-4 text-primary">How I Solved Them</h3>
            <p className="leading-relaxed">
              I overcame these challenges through iterative practice and reflection. For prompt
              engineering, I documented successful prompts and analyzed what made them effective.
              For file organization, I researched best practices and developed a consistent system
              tailored to my needs. To address the ethical challenges, I created personal
              guidelines for AI use and always maintained transparency about when and how I used AI
              tools in my work.
            </p>
          </div>

          <div>
            <h3 className="text-xl mb-4 text-primary">Future Applications</h3>
            <p className="leading-relaxed">
              These digital skills will be fundamental to my future career in software development
              and AI. I will apply my prompt engineering skills to work more effectively with AI
              coding assistants. My organizational skills will help me manage complex projects and
              collaborate with distributed teams. Most importantly, my understanding of responsible
              AI will guide me in developing ethical and transparent AI applications. As technology
              continues to evolve, these foundational digital literacy skills will enable me to
              adapt and continue learning throughout my career.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
