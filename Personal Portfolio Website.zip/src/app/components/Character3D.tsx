import { motion } from "motion/react";

export function Character3D() {
  return (
    <div className="px-16 py-12 w-full">
      <motion.div
        className="aspect-square bg-gradient-to-br from-primary/10 to-accent/5 rounded-2xl flex items-center justify-center border border-sidebar-border"
        initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
        animate={{ opacity: 1, scale: 1, rotate: 0 }}
        transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        whileHover={{ scale: 1.05, rotate: 2 }}
      >
        <div className="text-center">
          <motion.div
            className="text-6xl mb-4"
            animate={{
              rotate: [0, 10, -10, 0],
              scale: [1, 1.1, 1.1, 1]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            🎨
          </motion.div>
          <motion.p
            className="text-sm text-sidebar-foreground/70 uppercase tracking-wider"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            3D Character
          </motion.p>
        </div>
      </motion.div>
    </div>
  );
}
