import { motion } from "motion/react";
import { FileText, Link2, Image } from "lucide-react";

export function Evidence() {
  const evidenceItems = [
    { id: 1, type: "document", title: "File Organization Documentation" },
    { id: 2, type: "image", title: "Academic Search Process Screenshots" },
    { id: 3, type: "document", title: "Prompt Engineering Examples" },
    { id: 4, type: "link", title: "Collaborative Project Workspace" },
    { id: 5, type: "image", title: "AI-Generated Content Samples" },
    { id: 6, type: "document", title: "Responsible AI Ethics Paper" },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case "document":
        return <FileText className="w-8 h-8" />;
      case "link":
        return <Link2 className="w-8 h-8" />;
      case "image":
        return <Image className="w-8 h-8" />;
      default:
        return <FileText className="w-8 h-8" />;
    }
  };

  return (
    <section id="evidence" className="px-8 lg:px-16 py-24 bg-secondary/30">
      <motion.h2
        className="text-4xl tracking-tight mb-4"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        Evidence Gallery
      </motion.h2>
      <motion.p
        className="text-muted-foreground mb-12 max-w-2xl"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        Documentation and artifacts from completed assignments
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {evidenceItems.map((item, index) => (
          <motion.div
            key={item.id}
            className="bg-card border border-border rounded-lg p-8 flex flex-col items-center justify-center text-center hover:border-primary/50 transition-colors cursor-pointer"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
          >
            <div className="text-primary mb-4">{getIcon(item.type)}</div>
            <h3 className="text-sm">{item.title}</h3>
            <p className="text-xs text-muted-foreground mt-2">Click to view</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
