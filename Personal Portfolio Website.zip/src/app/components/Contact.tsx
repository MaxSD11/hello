import { motion } from "motion/react";
import { Mail, Linkedin, Github, Twitter } from "lucide-react";

export function Contact() {
  const contactMethods = [
    {
      icon: <Mail className="w-6 h-6" />,
      label: "Email",
      value: "ngdung@example.com",
      link: "mailto:ngdung@example.com",
    },
    {
      icon: <Linkedin className="w-6 h-6" />,
      label: "LinkedIn",
      value: "/in/ngdung",
      link: "https://linkedin.com/in/ngdung",
    },
    {
      icon: <Github className="w-6 h-6" />,
      label: "GitHub",
      value: "@ngdung",
      link: "https://github.com/ngdung",
    },
    {
      icon: <Twitter className="w-6 h-6" />,
      label: "Twitter",
      value: "@ngdung",
      link: "https://twitter.com/ngdung",
    },
  ];

  return (
    <section id="contact" className="px-8 lg:px-16 py-24 bg-sidebar text-sidebar-foreground">
      <div className="max-w-4xl mx-auto">
        <motion.h2
          className="text-4xl tracking-tight mb-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Contact
        </motion.h2>
        <motion.p
          className="text-sidebar-foreground/70 mb-12 max-w-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          Let's connect and collaborate on future projects
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {contactMethods.map((method, index) => (
            <motion.a
              key={method.label}
              href={method.link}
              className="bg-sidebar-accent border border-sidebar-border rounded-lg p-6 flex items-start gap-4 hover:border-primary transition-colors"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-primary">{method.icon}</div>
              <div>
                <h3 className="text-sm uppercase tracking-wider text-sidebar-foreground/70 mb-1">
                  {method.label}
                </h3>
                <p className="text-sidebar-foreground">{method.value}</p>
              </div>
            </motion.a>
          ))}
        </div>

        <motion.div
          className="mt-16 text-center text-sidebar-foreground/50 text-sm"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <p>© 2026 Ng Dung. Academic Portfolio for Digital Literacy & AI Course.</p>
        </motion.div>
      </div>
    </section>
  );
}
