import { motion } from "motion/react";

export function About() {
  return (
    <section id="about" className="px-8 lg:px-16 py-24 bg-secondary/30">
      <div className="max-w-4xl">
        <motion.h2
          className="text-4xl tracking-tight mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          About Me
        </motion.h2>
        <motion.div
          className="space-y-6 text-lg leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <p>
            I am <strong>Ng Dung</strong>, a software developer and AI learner with a passion for
            technology and digital innovation. My journey in computer science has equipped me with
            fundamental programming skills in <strong>C++</strong>, <strong>Python</strong>, and{" "}
            <strong>Java</strong>, forming the foundation of my technical expertise.
          </p>
          <p>
            Beyond traditional programming, I have developed a strong interest in artificial
            intelligence tools and their applications in modern software development. I am
            particularly fascinated by how AI can enhance productivity, creativity, and
            problem-solving in the digital realm.
          </p>
          <p>
            Through continuous digital learning and hands-on projects, I have cultivated skills in
            prompt engineering, generative AI applications, and responsible AI practices. This
            portfolio showcases my academic journey and the digital competencies I have developed
            to prepare for the evolving landscape of technology and AI.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
