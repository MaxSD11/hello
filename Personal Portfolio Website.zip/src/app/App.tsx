import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Skills } from "./components/Skills";
import { Projects } from "./components/Projects";
import { Evidence } from "./components/Evidence";
import { Reflection } from "./components/Reflection";
import { Contact } from "./components/Contact";

export default function App() {
  return (
    <div className="size-full overflow-auto scroll-smooth">
      <Navigation />

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center bg-sidebar text-sidebar-foreground">
        <Hero />
      </section>

      {/* Content Sections */}
      <About />
      <Skills />
      <Projects />
      <Evidence />
      <Reflection />
      <Contact />
    </div>
  );
}